#import<Foundation/Foundation.h>
@protocol KST <NSObject>
-(id) calcKST:(id) billAmt;
@end
