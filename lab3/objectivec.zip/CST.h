#import<Foundation/Foundation.h>
@protocol CST <NSObject>
-(id) calcCST:(id) billAmt;
@end
