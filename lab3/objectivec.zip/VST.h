#import<Foundation/Foundation.h>
@protocol VAT <NSObject>
-(id) calcVAT:(id) billAmt;
@end